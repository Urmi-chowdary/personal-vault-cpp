(async () => {
  const v = shell('dashboard', 'Dashboard');
  await guard(async () => {
    const d = await api('/dashboard');
    const stats = [['Applications', d.total_apps], ['Active permissions', d.active_permissions], ['High-risk requests', d.high_risk], ['Pending reviews', d.pending], ['Average risk score', d.avg_risk]];
    v.innerHTML = `<div class="grid g4">${stats.map(s => `<div class="card stat"><b>${esc(s[1])}</b><span>${s[0]}</span></div>`).join('')}</div>
    <div class="grid g2"><div class="card"><h3>Risk distribution</h3><canvas id="c1" height="200"></canvas></div><div class="card"><h3>Permission categories</h3><canvas id="c2" height="200"></canvas></div></div>
    <div class="grid g2"><div class="card"><h3>Recent activity</h3>${table([['Time', r => fmt(r.timestamp)], ['App', r => esc(r.app_name)], ['Action', r => esc(r.action)]], d.recent_activity || [])}</div>
    <div class="card"><h3>Risk by application</h3>${table([['App', r => esc(r.app_name)], ['Avg score', r => r.avg_score], ['Level', r => badge(r.level)]], d.app_risk || [])}</div></div>`;
    const rd = d.risk_distribution || {}, cc = d.category_counts || {};
    new Chart($('#c1'), { type: 'doughnut', data: { labels: ['Low', 'Medium', 'High', 'Critical'], datasets: [{ data: [rd.low || 0, rd.medium || 0, rd.high || 0, rd.critical || 0], backgroundColor: ['#4ade80', '#facc15', '#fb923c', '#f43f5e'], borderWidth: 0 }] }, options: { plugins: { legend: { labels: { color: '#e8eef7' } } } } });
    new Chart($('#c2'), { type: 'bar', data: { labels: CATEGORIES, datasets: [{ data: CATEGORIES.map(c => cc[c] || 0), backgroundColor: '#2dd4bf', borderRadius: 6 }] }, options: { plugins: { legend: { display: false } }, scales: { x: { ticks: { color: '#8fa1bd' } }, y: { ticks: { color: '#8fa1bd', precision: 0 }, beginAtZero: true } } } });
  });
})();
