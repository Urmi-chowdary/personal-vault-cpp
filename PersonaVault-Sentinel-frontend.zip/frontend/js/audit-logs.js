(async () => {
  const v = shell('audit-logs', 'Audit Logs');
  let all = [], key = 'timestamp', dir = -1;
  const cols = [['Time', 'timestamp'], ['Application', 'app_name'], ['Permission', 'permission'], ['Score', 'risk_score'], ['Decision', 'decision'], ['Reason', 'reason']];
  function view() {
    const q = $('#q').value.toLowerCase(), d = $('#d').value;
    const rows = all.filter(r => (!d || r.decision === d) && (!q || JSON.stringify(r).toLowerCase().includes(q))).sort((a, b) => (a[key] > b[key] ? 1 : a[key] < b[key] ? -1 : 0) * dir);
    $('#t').innerHTML = rows.length ? `<table><thead><tr>${cols.map(c => `<th class="sort" data-k="${c[1]}">${c[0]}${c[1] === key ? (dir > 0 ? ' ▲' : ' ▼') : ''}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr><td>${fmt(r.timestamp)}</td><td>${esc(r.app_name)}</td><td>${esc(r.permission)}</td><td>${r.risk_score ?? '-'}</td><td>${r.decision ? badge(r.decision) : '-'}</td><td>${esc(r.reason)}</td></tr>`).join('')}</tbody></table>` : '<div class="empty">No log entries match.</div>';
    return rows;
  }
  v.innerHTML = '<div class="card"><div class="row"><div><label for="q">Search</label><input id="q"></div><div><label for="d">Decision</label><select id="d"><option value="">All</option><option>Allow</option><option>Review</option><option>Deny</option></select></div><div style="flex:0"><button id="x">Export CSV</button></div></div></div><div class="card" id="t"></div>';
  all = await guard(() => api('/audit-logs')) || [];
  $('#q').oninput = $('#d').onchange = view;
  $('#t').onclick = e => { const h = e.target.closest('th'); if (!h) return; dir = key === h.dataset.k ? -dir : 1; key = h.dataset.k; view(); };
  $('#x').onclick = () => downloadCSV('audit-logs.csv', view());
  view();
})();
