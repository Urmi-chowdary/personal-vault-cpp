(async () => {
  const v = shell('risk-analysis', 'Risk Analysis');
  const rows = await guard(() => api('/permissions')) || [];
  v.innerHTML = `<div class="card"><h3>Analyze a request</h3><div class="row"><div><label for="r">Permission request</label><select id="r">${rows.map(r => `<option value="${r.id}">${esc(r.app_name)}: ${esc((r.categories || []).join(', '))}</option>`).join('')}</select></div><div style="flex:0"><button id="go">Run analysis</button></div></div></div>
  <div class="card" id="out"><div class="empty">Pick a request and run the analysis to see the score and every contributing factor.</div></div>
  <div class="card"><h3>Scoring weights</h3><p style="color:var(--mut)">0-29 Low, 30-59 Medium, 60-79 High, 80-100 Critical. Missing, expired, or revoked consent always blocks approval, whatever the score.</p></div>`;
  $('#go').onclick = () => guard(async () => { if (!$('#r').value) return toast('No requests to analyze', true); $('#out').innerHTML = explain(await api(`/permissions/${$('#r').value}/evaluate`, { method: 'POST' })); });
})();
