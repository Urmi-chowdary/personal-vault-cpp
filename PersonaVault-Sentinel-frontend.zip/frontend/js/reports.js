(async () => {
  const v = shell('reports', 'Reports & Settings');
  await guard(async () => {
    const [s, cfg] = await Promise.all([api('/reports/summary'), api('/settings')]);
    const sec = (id, title, cols, rows, file) => `<div class="card"><div class="row"><h3 style="flex:3">${title}</h3><div style="flex:0"><button class="ghost sm" data-x="${id}">Export CSV</button></div></div>${table(cols, rows)}</div>`;
    window._s = s;
    v.innerHTML = `<div class="grid g2"><div class="card"><h3>Permission distribution</h3><canvas id="c" height="200"></canvas></div><div class="card"><h3>Summary</h3><p>Total requests: <b>${s.total_requests ?? 0}</b></p><p>Denied: <b>${(s.denied || []).length}</b></p><p>High or critical risk: <b>${(s.high_risk || []).length}</b></p><p>Consent events: <b>${(s.consent_history || []).length}</b></p></div></div>` +
      sec('apps', 'Application-wise risk', [['App', r => esc(r.app_name)], ['Requests', r => r.requests], ['Avg score', r => r.avg_score], ['Denied', r => r.denied]], s.apps || []) +
      sec('denied', 'Denied requests', [['App', r => esc(r.app_name)], ['Categories', r => esc((r.categories || []).join(', '))], ['Score', r => r.risk_score], ['Reason', r => esc(r.reason)]], s.denied || []) +
      sec('high_risk', 'High-risk requests', [['App', r => esc(r.app_name)], ['Categories', r => esc((r.categories || []).join(', '))], ['Score', r => r.risk_score], ['Level', r => badge(r.risk_level)]], s.high_risk || []) +
      sec('consent_history', 'Consent history', [['App', r => esc(r.app_name)], ['Category', r => esc(r.category)], ['Status', r => badge(r.status)], ['Time', r => fmt(r.timestamp)]], s.consent_history || []) +
      `<div class="card"><h3>Settings</h3><div class="row"><div><label for="tm">Medium threshold</label><input id="tm" type="number" value="${cfg.medium_threshold}"></div><div><label for="th">High threshold</label><input id="th" type="number" value="${cfg.high_threshold}"></div><div><label for="tc">Critical threshold</label><input id="tc" type="number" value="${cfg.critical_threshold}"></div></div>
      <div class="row"><div><label for="pn">Demo profile name</label><input id="pn" value="${esc(localStorage.getItem('pv_user') || 'Demo User')}"></div><div><label for="po">Policy: block when consent is missing</label><select id="po"><option value="1" ${cfg.require_consent ? 'selected' : ''}>Yes (recommended)</option><option value="0" ${cfg.require_consent ? '' : 'selected'}>No</option></select></div></div>
      <p style="margin-top:12px"><button id="sv">Save settings</button></p></div>`;
    const cc = s.category_counts || {};
    new Chart($('#c'), { type: 'bar', data: { labels: CATEGORIES, datasets: [{ data: CATEGORIES.map(c => cc[c] || 0), backgroundColor: '#2dd4bf', borderRadius: 6 }] }, options: { plugins: { legend: { display: false } }, scales: { x: { ticks: { color: '#8fa1bd' } }, y: { ticks: { color: '#8fa1bd', precision: 0 }, beginAtZero: true } } } });
    v.onclick = e => { const b = e.target.closest('[data-x]'); if (b) downloadCSV(b.dataset.x + '-report.csv', window._s[b.dataset.x] || []); };
    $('#sv').onclick = () => guard(async () => {
      localStorage.setItem('pv_user', $('#pn').value.trim() || 'Demo User');
      await api('/settings', { method: 'PUT', body: { medium_threshold: +$('#tm').value, high_threshold: +$('#th').value, critical_threshold: +$('#tc').value, require_consent: $('#po').value === '1' } });
      toast('Settings saved');
    });
  });
})();
