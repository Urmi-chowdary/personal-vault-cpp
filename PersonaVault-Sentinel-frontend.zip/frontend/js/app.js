const NAV = [['dashboard','Dashboard'],['applications','Applications'],['permissions','Permissions'],['risk-analysis','Risk Analysis'],['consent','Consent Center'],['audit-logs','Audit Logs'],['reports','Reports & Settings']];
const LOGO = '<svg width="30" height="30" viewBox="0 0 32 32"><path d="M16 2 4 7v8c0 7.5 5 13 12 15 7-2 12-7.5 12-15V7z" fill="#2dd4bf"/><path d="M10.5 16l4 4 7-8" stroke="#0b1220" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const CATEGORIES = ['Photos','Location','Contacts','Documents','Microphone','Camera','Usage History'];
const $ = (s, e = document) => e.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const badge = v => `<span class="badge ${esc(String(v).toLowerCase())}">${esc(v)}</span>`;
const fmt = d => d ? esc(String(d).replace('T', ' ').slice(0, 16)) : '-';
function toast(msg, err) { const t = $('#toast'); t.textContent = msg; t.className = err ? 'err' : ''; t.style.display = 'block'; setTimeout(() => t.style.display = 'none', 3500); }
function shell(page, title) {
  document.body.innerHTML = `<aside class="side" id="side"><div class="brand">${LOGO}PersonaVault Sentinel</div><nav>${NAV.map(n => `<a href="${n[0]}.html" class="${n[0] === page ? 'on' : ''}">${n[1]}</a>`).join('')}</nav></aside>
  <main class="main"><header><button id="menu" aria-label="Menu">Menu</button><h1>${title}</h1><span class="user">${esc(localStorage.getItem('pv_user') || 'Demo User')}</span></header><div id="view"></div></main><div id="toast" role="status"></div>`;
  $('#menu').onclick = () => $('#side').classList.toggle('open');
  return $('#view');
}
async function guard(fn) { try { return await fn(); } catch (e) { toast(e.message, true); } }
function table(cols, rows, empty) {
  if (!rows.length) return `<div class="empty">${empty || 'Nothing here yet.'}</div>`;
  return `<table><thead><tr>${cols.map(c => `<th>${c[0]}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${cols.map(c => `<td>${c[1](r)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
}
function downloadCSV(name, rows) {
  if (!rows.length) return toast('No data to export', true);
  const keys = Object.keys(rows[0]);
  const q = v => '"' + String(Array.isArray(v) ? v.join('; ') : v ?? '').replace(/"/g, '""') + '"';
  const csv = [keys.join(','), ...rows.map(r => keys.map(k => q(r[k])).join(','))].join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = name; a.click();
}
function explain(r) {
  return `<div class="row"><div><div class="score">${r.score}</div>${badge(r.level)} ${badge(r.decision)}</div>
  <div style="flex:3"><div class="bar"><i style="width:${r.score}%;background:var(--${String(r.level).toLowerCase()})"></i></div>
  ${table([['Rule', x => esc(x.rule)], ['Points', x => '+' + x.points], ['Why', x => esc(x.reason)]], r.reasons || [], 'No risk factors triggered.')}
  <p style="margin-top:10px"><b>Safer configuration:</b> ${(r.safer_categories || []).length ? esc(r.safer_categories.join(', ')) : 'No changes suggested'}</p></div></div>`;
}
