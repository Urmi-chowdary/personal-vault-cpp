(async () => {
  const v = shell('applications', 'Applications');
  let apps = [], editId = null;
  async function load() {
    apps = await api('/applications');
    $('#list').innerHTML = table([['Name', a => esc(a.name)], ['Developer', a => esc(a.developer)], ['Declared purpose', a => esc(a.purpose)],
      ['', a => `<button class="sm ghost" data-h="${a.id}">History</button><button class="sm ghost" data-e="${a.id}">Edit</button><button class="sm danger" data-d="${a.id}">Delete</button>`]], apps, 'No applications yet. Register one above.');
  }
  v.innerHTML = `<div class="card"><h3 id="ft">Register application</h3><div class="row"><div><label for="n">Name</label><input id="n"></div><div><label for="dv">Developer</label><input id="dv"></div></div>
  <label for="p">Declared purpose</label><input id="p" placeholder="e.g. Edit and enhance photos"><p style="margin-top:12px"><button id="save">Save application</button> <button id="cancel" class="ghost" hidden>Cancel</button></p></div>
  <div class="card" id="list"></div><div class="card" id="hist" hidden></div>`;
  $('#save').onclick = () => guard(async () => {
    const body = { name: $('#n').value.trim(), developer: $('#dv').value.trim(), purpose: $('#p').value.trim() };
    await api(editId ? '/applications/' + editId : '/applications', { method: editId ? 'PUT' : 'POST', body });
    toast(editId ? 'Application updated' : 'Application registered');
    editId = null; $('#cancel').hidden = true; $('#ft').textContent = 'Register application'; ['n', 'dv', 'p'].forEach(i => $('#' + i).value = ''); await load();
  });
  $('#cancel').onclick = () => { editId = null; $('#cancel').hidden = true; $('#ft').textContent = 'Register application'; ['n', 'dv', 'p'].forEach(i => $('#' + i).value = ''); };
  $('#list').onclick = e => guard(async () => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.e) { const a = apps.find(x => x.id == b.dataset.e); editId = a.id; $('#n').value = a.name; $('#dv').value = a.developer; $('#p').value = a.purpose; $('#ft').textContent = 'Edit application'; $('#cancel').hidden = false; scrollTo(0, 0); }
    if (b.dataset.d && confirm('Delete this application and its requests?')) { await api('/applications/' + b.dataset.d, { method: 'DELETE' }); toast('Application deleted'); await load(); $('#hist').hidden = true; }
    if (b.dataset.h) { const p = await api('/permissions?app_id=' + b.dataset.h); const h = $('#hist'); h.hidden = false;
      h.innerHTML = '<h3>Permission history</h3>' + table([['Categories', r => esc((r.categories || []).join(', '))], ['Status', r => badge(r.status)], ['Score', r => r.risk_score ?? '-'], ['Decision', r => r.decision ? badge(r.decision) : '-']], p, 'No permission requests for this application.'); }
  });
  await guard(load);
})();
