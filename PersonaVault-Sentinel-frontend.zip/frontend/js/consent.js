(async () => {
  const v = shell('consent', 'Consent Center');
  async function load() {
    const c = await api('/consents');
    v.innerHTML = '<div class="card">' + table([['App', r => esc(r.app_name)], ['Category', r => esc(r.category)], ['Status', r => badge(r.status)], ['Granted', r => fmt(r.granted_at)], ['Expires', r => fmt(r.expires_at)], ['Revoked', r => fmt(r.revoked_at)],
      ['', r => `<button class="sm ghost" data-g="${r.permission_id}">Grant / renew</button><button class="sm danger" data-r="${r.permission_id}">Revoke</button>`]], c, 'No consent records yet.') + '</div>';
  }
  v.onclick = e => guard(async () => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.g) { const d = prompt('Expiry date (YYYY-MM-DD), blank for none'); if (d === null) return; await api(`/permissions/${b.dataset.g}/approve`, { method: 'POST', body: { expires_at: d || null } }); await api(`/permissions/${b.dataset.g}/evaluate`, { method: 'POST' }); toast('Consent granted and request re-evaluated'); }
    if (b.dataset.r) { await api(`/permissions/${b.dataset.r}/revoke`, { method: 'POST' }); await api(`/permissions/${b.dataset.r}/evaluate`, { method: 'POST' }); toast('Consent revoked and request re-evaluated'); }
    await load();
  });
  await guard(load);
})();
