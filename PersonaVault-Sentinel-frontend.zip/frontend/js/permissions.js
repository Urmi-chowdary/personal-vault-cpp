(async () => {
  const v = shell('permissions', 'Permissions');
  let apps = [];
  async function load() {
    const q = new URLSearchParams({ app_id: $('#fa').value, category: $('#fc').value });
    [...q.keys()].forEach(k => !q.get(k) && q.delete(k));
    const rows = await api('/permissions' + (q.toString() ? '?' + q : ''));
    $('#list').innerHTML = table([['App', r => esc(r.app_name)], ['Categories', r => esc((r.categories || []).join(', '))], ['Purpose', r => esc(r.purpose)], ['Status', r => badge(r.status)],
      ['Risk', r => r.risk_score == null ? '-' : r.risk_score + ' ' + badge(r.risk_level)], ['Expires', r => fmt(r.expires_at)],
      ['', r => ['evaluate', 'approve', 'deny', 'revoke'].map(a => `<button class="sm ${a === 'deny' || a === 'revoke' ? 'danger' : 'ghost'}" data-a="${a}" data-id="${r.id}">${a[0].toUpperCase() + a.slice(1)}</button>`).join('')]], rows, 'No requests match these filters.');
  }
  apps = await guard(() => api('/applications')) || [];
  const opts = apps.map(a => `<option value="${a.id}">${esc(a.name)}</option>`).join('');
  v.innerHTML = `<div class="card"><h3>Submit permission request</h3><div class="row"><div><label for="app">Application</label><select id="app">${opts}</select></div><div><label for="ex">Expiry date</label><input id="ex" type="date"></div></div>
  <label>Data categories</label><div class="checks">${CATEGORIES.map(c => `<label><input type="checkbox" value="${c}">${c}</label>`).join('')}</div>
  <label for="pu">Purpose of this request</label><input id="pu"><p style="margin-top:12px"><button id="sub">Submit request</button></p></div>
  <div class="card"><div class="row"><div><label for="fa">Application</label><select id="fa"><option value="">All</option>${opts}</select></div><div><label for="fc">Category</label><select id="fc"><option value="">All</option>${CATEGORIES.map(c => `<option>${c}</option>`).join('')}</select></div></div></div>
  <div class="card" id="list"></div><div class="card" id="res" hidden></div>`;
  $('#fa').onchange = $('#fc').onchange = () => guard(load);
  $('#sub').onclick = () => guard(async () => {
    const categories = [...document.querySelectorAll('.checks input:checked')].map(i => i.value);
    const r = await api('/permissions', { method: 'POST', body: { app_id: +$('#app').value, categories, purpose: $('#pu').value.trim(), expires_at: $('#ex').value || null } });
    toast('Request submitted'); await load();
    const res = await api('/permissions/' + r.id + '/evaluate', { method: 'POST' }); $('#res').hidden = false; $('#res').innerHTML = '<h3>Evaluation result</h3>' + explain(res); await load();
  });
  $('#list').onclick = e => guard(async () => {
    const b = e.target.closest('button'); if (!b) return;
    const res = await api(`/permissions/${b.dataset.id}/${b.dataset.a}`, { method: 'POST' });
    if (b.dataset.a === 'evaluate') { $('#res').hidden = false; $('#res').innerHTML = '<h3>Evaluation result</h3>' + explain(res); }
    else toast('Request ' + b.dataset.a + (b.dataset.a.endsWith('e') ? 'd' : 'ed'));
    await load();
  });
  await guard(load);
})();
